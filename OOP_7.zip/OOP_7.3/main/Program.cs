﻿using System;
using System.IO;

namespace OOP_7_3
{
    public class CopyFileUpper
    {
        public static void Main()
        {
            string sFrom, sTo;

            StreamReader srFrom;
            StreamWriter swTo;

            Console.WriteLine("Enter file name for input: ");
            sFrom = Console.ReadLine();

            Console.WriteLine("Enter file name for output: ");
            sTo = Console.ReadLine();

            try
            {
                srFrom = new StreamReader(sFrom);
                swTo = new StreamWriter(sTo);

                while (srFrom.Peek() != -1)
                {
                    string sBuffer = srFrom.ReadLine();
                    sBuffer = sBuffer.ToUpper();
                    swTo.WriteLine(sBuffer);
                }

                swTo.Close();
                srFrom.Close();
            }
            catch (FileNotFoundException)
            {
                Console.WriteLine("Couldn't find a file");
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
    }
}
