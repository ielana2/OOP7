﻿using System;

namespace main
{
    enum AccountType
    {
        Checking,
        Deposit
    }
    class BankAccount
    {
        private long accNo;
        private decimal accBal;
        private AccountType accType;

        private static long nextNumber = 123;

        public void Populate(decimal balance)
        {
            accNo = NextNumber();
            accBal = balance;
            accType = AccountType.Checking;
        }

        public bool Withdraw(decimal amount)
        {
            bool sufficientFunds = accBal >= amount;
            if (sufficientFunds)
            {
                accBal -= amount;
            }
            return sufficientFunds;
        }

        public decimal Deposit(decimal amount)
        {
            accBal += amount;
            return accBal;
        }

        public long Number()
        {
            return accNo;
        }

        public decimal Balance()
        {
            return accBal;
        }

        public string Type()
        {
            string accountType = accType.ToString();
            return accountType;
        }

        private static long NextNumber()
        {
            return nextNumber++;
        }

        public void TransferFrom(ref BankAccount accForm, decimal ammount)
        {
            if (accForm.Withdraw(ammount))
            {
                Deposit(ammount);
            }
        }
    }
    public class Test
    {
        public static void Main()
        {
            BankAccount b1 = new BankAccount();
            BankAccount b2 = new BankAccount();

            b1.Populate(100);
            b2.Populate(100);

            AccountInfo(ref b1);
            AccountInfo(ref b2);

            b1.TransferFrom(ref b2, 10);

            AccountInfo(ref b1);
            AccountInfo(ref b2);
        }

        static void AccountInfo(ref BankAccount getInfo)
        {
            Console.WriteLine("Account number is {0}", getInfo.Number());
            Console.WriteLine("Account balance is {0}", getInfo.Balance());
            Console.WriteLine("Account type is {0}", getInfo.Type());
            Console.WriteLine(" ");
        }
    }
}
